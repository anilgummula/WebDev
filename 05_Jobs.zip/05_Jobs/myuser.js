let logoutbtn=document.querySelector('#logout');



// popup js
document.addEventListener("DOMContentLoaded", function() {
    let contactus=document.querySelector("#contact");
    let cpopup=document.querySelector('#cpopup');
    var closeBtn = document.querySelector('.cclose');


    contactus.addEventListener('click', function() {
        cpopup.style.display = 'flex';
        // login
    });
    

    closeBtn.addEventListener('click', function() {
        cpopup.style.display = 'none';
        window.refresh();
    });
    
    
    // window.addEventListener('click', function(event) {
    //     if (event.target === popup) {
    //         popup.style.display = 'none';
    //     }
    // });
    let newbtn=document.querySelector('#btnnew');
    let card=document.querySelector('.cards');
    let container=document.querySelector('.container');
    
    
    newbtn.addEventListener('click',function(){
        let newcard=card.cloneNode(true);
        container.appendChild(newcard);
    });
});
// popup end



// user profile
document.addEventListener("DOMContentLoaded",function(){
    let profilebtn=document.querySelector("#userprofile");
    let udpopup=document.querySelector("#udpopup");
    let udclose=document.querySelector(".udclose");
    profilebtn.addEventListener('click',function(){
        udpopup.style.display='flex';

    });
    udclose.addEventListener('click',function(){
        udpopup.style.display='none';
    });
});


