function f1(){
    let name=document.getElementById("name").value;
    let email=document.getElementById("email").value;
    let pass=document.getElementById("pwd").value;
    let repass=document.getElementById("cpwd").value;

    if(name!=0&&email!=0){

        if(pass==repass && pass!=0){
            document.getElementById("main").remove();
            document.getElementById("final").innerHTML+="<h1>SignUp Successfull!</h1>";
        
            document.getElementById("final").style.textAlign="center";
            document.getElementById("final").style.marginTop="150px";
            document.getElementById("body").style.backgroundImage=url("");
        
        
        }
        else{
            if(pass==0){
                document.getElementById("warn").innerHTML="<p>*password should not be empty</p>";
            }
            else{
                document.getElementById("warn").innerHTML="<p style=color: red>*password don't match</p>";
            }
        }

    }
    else{
        document.getElementById("warn").innerHTML="<p style=color: red>*Name and Email fields should not be empty</p>";
    }
}


// to show password
function show(){
    var c=document.getElementById("pwd");
    if(c.type==="password"){
        c.type="text";
    }
    else{

        c.type="password";
    }
}
//to refresh page
function refresh(){
    location.reload(true);
}
