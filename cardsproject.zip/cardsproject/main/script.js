const newcardbtn = document.querySelector('.btnone');
const oldcardbtn = document.querySelector('#con1');
// const newcarddiv = document.querySelector('.newcontainer');
const newcarddiv = document.querySelector('.newone');

document.addEventListener("DOMContentLoaded", function() {
    var popupBtn1 = document.querySelector('#login');
    var popupBtn2 = document.querySelector('#reg');
    var popup = document.getElementById('popup');
    var closeBtn = document.querySelector('.close-btn');

    popupBtn1.addEventListener('click', function() {
        popup.style.display = 'flex';
    });
    popupBtn2.addEventListener('click', function() {
        popup.style.display = 'flex';
    });

    // closeBtn.addEventListener('click', function() {
    //     popup.style.display = 'none';
    // });
    closeBtn.addEventListener('click', function() {
        popup.style.display = 'none';
        window.refresh();
    });

    // window.addEventListener('click', function(event) {
    //     if (event.target === popup) {
    //         popup.style.display = 'none';
    //     }
    // });
});




// for popup login page
function f1(){
    let name=document.getElementById("name").value;
    let email=document.getElementById("email").value;
    let pass=document.getElementById("pwd").value;
    let repass=document.getElementById("cpwd").value;

    if(name!=0&&email!=0){
    // if(true){

        if(pass==repass && pass!=0){
        // if(1){
            // document.getElementById("main").remove();
            // document.getElementById("final").innerHTML+="<h1>SignUp Successfull!</h1>";
        
            // document.getElementById("final").style.textAlign="center";
            // document.getElementById("final").style.marginTop="150px";
            // document.getElementById("body").style.backgroundImage=url("");
            const popup=document.querySelector('#popup');
            popup.style.display = 'none';

        
        
        }
        else{
            if(pass==0){
                document.getElementById("warn").innerHTML="<p>*password should not be empty</p>";
            }
            else{
                document.getElementById("warn").innerHTML="<p style=color: red>*password don't match</p>";
            }
        }

    }
    else{
        document.getElementById("warn").innerHTML="<p style=color: red>*Name and Email fields should not be empty</p>";
    }
}


// to show password
function show(){
    var c=document.getElementById("pwd");
    var c2=document.getElementById("cpwd");
    if(c.type==="password"){
        c.type="text";
        c2.type="text";
    }
    else{

        c.type="password";
        c2.type="password";
    }
}
//to refresh page
function refresh(){
    location.reload(true);
}

