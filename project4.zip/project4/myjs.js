function f1(){
    let name=document.getElementById("name").value;
    let email=document.getElementById("email").value;
    let pass=document.getElementById("pass").value;
    let repass=document.getElementById("repass").value;

    if(name!=0&&email!=0){

        if(pass==repass && pass!=0){
        document.getElementById("main").remove();
        document.getElementById("final").innerHTML+="<h1>SignUp Successfull!</h1>";
        // document.getElementById("final").innerHTML+="<img src=images/success.png>";
        // document.getElementById("final").innerHTML+="<img src=images/success.png id=img>";
        // document.getElementById("img").style.width="30px";
    
        document.getElementById("final").style.textAlign="center";
        document.getElementById("final").style.marginTop="150px";
        document.getElementById("body").style.backgroundImage=url(" ");
        }
        else{
            if(pass==0){
                document.getElementById("warn").innerHTML="<p style=color: red>*password should not be empty</p>";
            }
            else{
                document.getElementById("warn").innerHTML="<p style=color: red>*password don't match</p>";
            }
        }

    }
    else{
        document.getElementById("warn").innerHTML="<p style=color: red>*Name and Email fields should not be empty</p>";
    }
}