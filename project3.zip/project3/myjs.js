    // document.getElementById("refresh").remove();
    let x=1; 
    let img="images/img7.jpg";
    function f1(){
        // for(let i=0;i<10;i++){
            
            // }
            x++;
            if(x>9){
                x=0;
            }
            img="images/img"+x+".jpg";
            document.getElementById("image").src=img;
        }
        function f2(){
            x--;
            if(x<0){
            x=9;
        }
        img="images/img"+x+".jpg";
        document.getElementById("image").src=img;

    }
    function f3(){
        let u="url("+img+")";
        document.getElementById("body").style.backgroundImage=u;
        document.getElementById("body").style.backgroundSize="cover";
        document.getElementById("body").style.backgroundPosition="top";
        document.getElementById("box1").remove();
        document.getElementById("box2").remove();
        document.getElementById("head").remove();
        // document.getElementById("refresh").style.display="block";
        // document.getElementById("body").style.backgroundColor=
    }
    function f4(){
        location.reload(true);
    }