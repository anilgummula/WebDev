function validate(){
    // for name
    let name=document.getElementById("name").value;
    let email=document.getElementById("email").value;
    let pwd=document.getElementById("pwd").value;
    let cpwd=document.getElementById("cpwd").value;
    let CLcheck=0;
    let SLcheck=0;
    let NOcheck=0;
    let SCcheck=0;
    if(name==""){
        alert("Name field should not be empty!");
        return false;
    }
    // for email
    else if(email==""){
        alert("Email field should not be empty!");
        return false;
    }
    else if(pwd==''){
        alert("Password field should not be empty!")
        return false;
    }
    
    else{
        if(pwd.length<8){
            alert("Password must be atleast of 8 Characters!");
            return false;
        }
        for(let i=0;i<pwd.length;i++){
            let p=pwd.charCodeAt(i);
            if(p>=65 && p<=90){
                // alert("A Capital letter passed");
                CLcheck++;
                // continue;
            }
            else if(p==95|| p==64 || p==32 || p==35){
                // alert("A Special char passed");
                SCcheck++;
                // continue;1
            } 
            else if(p>=97 && p<=122){
                // alert("A Small letter passed");
                SLcheck++;
                // continue;
            }    
            else if(p>=48 && p<=57){
                // alert("A Number passed");
                
                NOcheck++;
                // continue;
            } 
        }
        // NOcheck++;
        if(CLcheck==0||SLcheck==0||NOcheck==0||SCcheck==0){
            alert("Password must contain: \n1)A special character\n2)A Number\n3)A Small letter\n4)A capital letter");
            return false;
            
        }
        else if(pwd!=cpwd){
            alert("The Password not matched!")
            return false;
        }
        else{
            // alert("Registration successfull!");          
            document.getElementById("main").remove();
            document.getElementById("final").innerHTML+="<h1>Registration Successfull!</h1>";
        
            document.getElementById("final").style.textAlign="center";
            document.getElementById("final").style.marginTop="180px";
            document.getElementById("body").style.backgroundImage="url(source/2-sea-full-moon.jpg)";
            // document.getElementById("body").style.backgroundPosition="center";
            document.getElementById("body").style.backgroundSize="cover";
            return true;
            // document.getElementById("body").style.backgroundImage=url("");
        }
        
    }
}
//To show password
function show(){
    var c=document.getElementById("pwd");
    if(c.type==="password"){
        c.type="text";
    }
    else{

        c.type="password";
    }
}
//to refresh page
function refresh(){
    location.reload(true);
}
